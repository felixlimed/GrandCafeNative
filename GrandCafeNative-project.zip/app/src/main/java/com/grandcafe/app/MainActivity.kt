package com.grandcafe.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF101722)
private val Panel = Color(0xFF1D2938)
private val Gold = Color(0xFFF5B32F)
private val Muted = Color(0xFF9EACBD)
private val White = Color(0xFFF5F7FA)

data class Dish(val id: Int, val name: String, val category: String, val price: Number, val unit: String = "")
private val allDishes = listOf(
    Dish(1, "Шакаран", "Салаты", 250, ""),
    Dish(2, "Колхозный", "Салаты", 270, ""),
    Dish(3, "Мужской каприз", "Салаты", 310, ""),
    Dish(4, "Греческий", "Салаты", 330, ""),
    Dish(5, "Цезарь с курицей", "Салаты", 340, ""),
    Dish(6, "Салат острый с язычком", "Салаты", 380, ""),
    Dish(7, "Запечённый салат с овощами", "Салаты", 450, ""),
    Dish(8, "Овощная нарезка", "Холодные закуски", 450, ""),
    Dish(9, "Сырная доска", "Холодные закуски", 600, ""),
    Dish(10, "Рыбная нарезка", "Холодные закуски", 650, ""),
    Dish(11, "Фруктовая тарелка", "Холодные закуски", 700, ""),
    Dish(12, "Сухарики с сыром", "Горячие закуски", 250, ""),
    Dish(13, "Кольца кальмара", "Горячие закуски", 320, ""),
    Dish(14, "Сырные палочки", "Горячие закуски", 350, ""),
    Dish(15, "Жаренные колбаски", "Горячие закуски", 650, ""),
    Dish(16, "Сет из закусок к пиву", "Горячие закуски", 1500, ""),
    Dish(17, "Мастава", "Первые блюда", 300, ""),
    Dish(18, "Чучвара с бульоном", "Первые блюда", 320, ""),
    Dish(19, "Острый рамен", "Первые блюда", 350, ""),
    Dish(20, "Мясо по-казахски", "Первые блюда", 360, ""),
    Dish(21, "Шорпо из домашней курочки", "Первые блюда", 360, ""),
    Dish(22, "Шорпо из говядины", "Первые блюда", 400, ""),
    Dish(23, "Шорпо Куват", "Первые блюда", 590, ""),
    Dish(24, "Манты из говядины", "Вторые блюда", 60, "шт"),
    Dish(25, "Карын манты", "Вторые блюда", 120, "шт"),
    Dish(26, "Ташкентский плов", "Вторые блюда", 330, ""),
    Dish(27, "Лагман", "Вторые блюда", 350, ""),
    Dish(28, "Карын куурдак", "Вторые блюда", 350, ""),
    Dish(29, "Ачуу эт", "Вторые блюда", 650, ""),
    Dish(30, "Кабырга куурдак", "Вторые блюда", 650, ""),
    Dish(31, "Кой куурдак", "Вторые блюда", 750, ""),
    Dish(32, "Курица с овощами", "Вторые блюда", 410, ""),
    Dish(33, "Курица в кисло-сладком", "Вторые блюда", 450, ""),
    Dish(34, "Мясо по-китайски", "Вторые блюда", 500, ""),
    Dish(35, "Жеже куурдак", "Вторые блюда", 650, ""),
    Dish(36, "Уй шыйрак", "Блюда на компанию", 550, ""),
    Dish(37, "Голова барашка маленькая", "Блюда на компанию", 800, ""),
    Dish(38, "Голова барашка средняя", "Блюда на компанию", 1000, ""),
    Dish(39, "Голова барашка большая", "Блюда на компанию", 1150, ""),
    Dish(40, "Сет из говядины на 1 персону", "Блюда на компанию", 650, ""),
    Dish(41, "Сет из говядины на 3 персоны", "Блюда на компанию", 1800, ""),
    Dish(42, "Сет из говядины на 4 персоны", "Блюда на компанию", 2300, ""),
    Dish(43, "Сет из говядины на 6 персон", "Блюда на компанию", 2800, ""),
    Dish(44, "Хлеб", "Гарниры", 50, ""),
    Dish(45, "Картошка фри", "Гарниры", 180, ""),
    Dish(46, "Картошка по-деревенски", "Гарниры", 180, ""),
    Dish(47, "Отварной рис", "Гарниры", 180, ""),
    Dish(48, "Маргарита", "Пицца", 560, ""),
    Dish(49, "Пепперони", "Пицца", 630, ""),
    Dish(50, "Цезарь", "Пицца", 630, ""),
    Dish(51, "Мексиканская острая", "Пицца", 630, ""),
    Dish(52, "Четыре сыра", "Пицца", 650, ""),
    Dish(53, "Четыре сезона", "Пицца", 650, ""),
    Dish(54, "Мясное ассорти", "Пицца", 650, ""),
    Dish(55, "Куриное филе", "Шашлыки", 220, ""),
    Dish(56, "Куриные крылышки", "Шашлыки", 220, ""),
    Dish(57, "Кебаб", "Шашлыки", 250, ""),
    Dish(58, "Кусковая говядина", "Шашлыки", 280, ""),
    Dish(59, "Кусковая баранина", "Шашлыки", 300, ""),
    Dish(60, "Язык на мангале", "Шашлыки", 310, ""),
    Dish(62, "Бонаква", "Прохладительные", 80, "1л"),
    Dish(63, "Боржоми", "Прохладительные", 170, "1л"),
    Dish(64, "Тан", "Прохладительные", 170, "1л"),
    Dish(65, "Чалап", "Прохладительные", 170, "1л"),
    Dish(66, "Кола / Фанта / Спрайт / Пепси", "Прохладительные", 180, "1л"),
    Dish(67, "Сок в ассортименте", "Прохладительные", 240, "1л"),
    Dish(68, "Лимонады в ассортименте", "Прохладительные", 280, "1л"),
    Dish(69, "Мурок (морс)", "Алайкуу", 120, "0.5л"),
    Dish(70, "Чалап", "Алайкуу", 170, "0.9л"),
    Dish(71, "Аксерке (жидкий курут)", "Алайкуу", 170, "0.9л"),
    Dish(72, "Чий (жидкий курут)", "Алайкуу", 190, "0.9л"),
    Dish(73, "Чай чёрный / зелёный", "Согревающие", 50, ""),
    Dish(74, "Чай с лимоном", "Согревающие", 130, ""),
    Dish(75, "Облепиховый чай", "Согревающие", 180, ""),
    Dish(76, "Имбирный чай", "Согревающие", 180, ""),
    Dish(77, "Малиновый чай", "Согревающие", 180, ""),
    Dish(78, "Фруктовый чай", "Согревающие", 200, ""),
    Dish(79, "Арпа", "Бутылочное пиво", 220, "0.5л"),
    Dish(80, "Бланш", "Бутылочное пиво", 220, "0.5л"),
    Dish(81, "Гараж", "Бутылочное пиво", 240, "0.5л"),
    Dish(82, "Эсса", "Бутылочное пиво", 240, "0.5л"),
    Dish(83, "Бад", "Бутылочное пиво", 250, "0.5л"),
    Dish(84, "Стелла", "Бутылочное пиво", 270, "0.5л"),
    Dish(85, "Хугарден", "Бутылочное пиво", 270, "0.5л"),
    Dish(86, "Корона Экстра", "Бутылочное пиво", 290, "0.5л"),
    Dish(87, "Нитро", "Энергетики", 170, ""),
    Dish(88, "Редбул", "Энергетики", 240, ""),
    Dish(89, "Бавария", "Пиво на розлив", 170, "0.5л"),
    Dish(90, "Бархатное", "Пиво на розлив", 180, "0.5л"),
    Dish(91, "Чешское", "Пиво на розлив", 180, "0.5л"),
    Dish(92, "Урбан", "Пиво на розлив", 200, "0.5л"),
    Dish(93, "Барон де Виллар (фр.)", "Вино", 1000, ""),
    Dish(94, "Monte Rosso (ит.)", "Вино", 1200, ""),
    Dish(95, "Марани (груз.)", "Вино", 1500, ""),
    Dish(96, "Талка", "Водка", 110, "50г"),
    Dish(97, "Органик", "Водка", 110, "50г"),
    Dish(98, "Столичная", "Водка", 130, "50г"),
    Dish(99, "Настроение", "Водка", 130, "50г"),
    Dish(100, "Архангельская", "Водка", 160, "50г"),
    Dish(101, "Финляндия", "Водка", 180, "50г"),
    Dish(102, "Русский стандарт", "Водка", 180, "50г"),
    Dish(103, "Белуга", "Водка", 300, "50г"),
    Dish(104, "Семетей", "Коньяк", 150, "50г"),
    Dish(105, "Бишкек", "Коньяк", 150, "50г"),
    Dish(106, "Кыргызстан", "Коньяк", 160, "50г"),
    Dish(107, "Маккалестер", "Виски", 260, "50г"),
    Dish(108, "Вильям Лоусонс", "Виски", 280, "50г"),
    Dish(109, "Магрегор", "Виски", 290, "50г"),
    Dish(110, "Джек Дениелс", "Виски", 350, "50г"),
    Dish(111, "Жеймсон", "Виски", 370, "50г"),
    Dish(112, "Апероль", "Импортные", 220, ""),
    Dish(113, "Сиерра сильвер", "Импортные", 240, ""),
    Dish(114, "Сиерра репосадо", "Импортные", 260, ""),
    Dish(115, "Ром Бакарди бланка", "Импортные", 270, ""),
    Dish(116, "Вермут мартини", "Импортные", 270, ""),
    Dish(117, "Егермейстер", "Импортные", 320, ""),
    Dish(118, "Джин бомбей", "Импортные", 350, ""),
    Dish(119, "Джин тоник", "Коктейли", 290, ""),
    Dish(120, "Секс на пляже", "Коктейли", 330, ""),
    Dish(121, "Лонг Айленд", "Коктейли", 330, ""),
    Dish(122, "Голубая лагуна", "Коктейли", 350, ""),
    Dish(123, "Лимон", "Снеки", 90, ""),
    Dish(124, "Курут", "Снеки", 130, ""),
    Dish(125, "Чипсы", "Снеки", 130, ""),
    Dish(126, "Арахис", "Снеки", 140, ""),
    Dish(127, "Чечел", "Снеки", 160, ""),
    Dish(128, "Фисташки", "Снеки", 160, ""),
    Dish(129, "Сет из сухофруктов", "Снеки", 550, ""),
    Dish(130, "Мальборо", "Сигареты", 270, ""),
    Dish(131, "Винстон", "Сигареты", 270, ""),
    Dish(132, "Мевиус", "Сигареты", 270, ""),
    Dish(133, "Ричмонд", "Сигареты", 280, ""),
    Dish(134, "Парламент", "Сигареты", 280, ""),
    Dish(135, "Эссе в ассортименте", "Сигареты", 280, ""),
)
private val popularIds = listOf(26, 27, 49, 24, 5, 57, 33, 45)
private val popularRatings = mapOf(26 to "4.9", 27 to "4.8", 49 to "4.8", 24 to "4.7", 5 to "4.7", 57 to "4.8", 33 to "4.6", 45 to "4.6")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GrandCafeApp() }
    }
}

@Composable
fun GrandCafeApp() {
    var page by remember { mutableStateOf("Главная") }
    var search by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Все") }
    val cart = remember { mutableStateMapOf<Int, Int>() }
    val categories = remember { listOf("Все") + allDishes.map { it.category }.distinct() }
    val cartCount = cart.values.sum()
    val cartTotal = allDishes.filter { cart.containsKey(it.id) }.sumOf { (it.price.toDouble() * (cart[it.id] ?: 0)) }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Gold, background = Bg, surface = Panel,
        onPrimary = Color.Black, onBackground = White, onSurface = White
    )) {
        Column(Modifier.fillMaxSize().background(Bg)) {
            Row(
                Modifier.fillMaxWidth().background(Panel).padding(horizontal = 18.dp, vertical = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("ГРАНД кафе", color = Gold, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                    Text("Вкусно. По-домашнему.", color = Muted, fontSize = 12.sp)
                }
                Text("🛍 $cartCount", color = Gold, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { page = "Корзина" })
            }
            when (page) {
                "Главная" -> {
                    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        item {
                            Column(Modifier.fillMaxWidth().background(
                                androidx.compose.ui.graphics.Brush.linearGradient(listOf(Color(0xFF374151), Color(0xFF202B39))),
                                RoundedCornerShape(22.dp)
                            ).padding(20.dp)) {
                                Text("ДОБРО ПОЖАЛОВАТЬ", color = Gold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(8.dp))
                                Text("Вкус начинается\nс хорошего выбора", color = White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 30.sp)
                                Spacer(Modifier.height(8.dp))
                                Text("Выбирай любимые блюда и собирай заказ в пару касаний.", color = Muted, fontSize = 14.sp)
                                Spacer(Modifier.height(16.dp))
                                Button(onClick = { page = "Меню" }, colors = ButtonDefaults.buttonColors(containerColor = Gold), shape = RoundedCornerShape(12.dp)) {
                                    Text("Открыть меню →", color = Color.Black, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                        item { Text("⭐ Рейтинг блюд", color = White, fontSize = 21.sp, fontWeight = FontWeight.Bold) }
                        items(allDishes.filter { popularIds.contains(it.id) }) { dish ->
                            DishCard(dish, popularRatings[dish.id] ?: "4.7", cart[dish.id] ?: 0,
                                onAdd = { cart[dish.id] = (cart[dish.id] ?: 0) + 1 },
                                onRemove = { val n=(cart[dish.id] ?: 0)-1; if(n<=0) cart.remove(dish.id) else cart[dish.id]=n })
                        }
                        item {
                            Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(18.dp)) {
                                Text("Почему ГРАНД?", color = Gold, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(8.dp))
                                Text("🍽 Разнообразное меню\n✨ Уютная атмосфера\n💛 Внимание к каждому гостю", color = White, lineHeight = 26.sp)
                            }
                        }
                    }
                }
                "Меню" -> {
                    Column(Modifier.fillMaxSize().padding(horizontal = 14.dp)) {
                        Spacer(Modifier.height(12.dp))
                        BasicTextField(
                            value = search, onValueChange = { search = it },
                            modifier = Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).padding(14.dp),
                            singleLine = true, textStyle = androidx.compose.ui.text.TextStyle(color = White, fontSize = 15.sp),
                            decorationBox = { inner -> if (search.isEmpty()) Text("Поиск блюда…", color = Muted); inner() }
                        )
                        Spacer(Modifier.height(10.dp))
                        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            categories.forEach { c ->
                                FilterChip(selected = category == c, onClick = { category = c },
                                    label = { Text(c, maxLines = 1) },
                                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Gold, selectedLabelColor = Color.Black))
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        val filtered = allDishes.filter {
                            (category == "Все" || it.category == category) &&
                            it.name.contains(search, ignoreCase = true)
                        }
                        Text("${filtered.size} блюд", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(vertical = 4.dp))
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 14.dp)) {
                            items(filtered) { dish ->
                                DishCard(dish, null, cart[dish.id] ?: 0,
                                    onAdd = { cart[dish.id] = (cart[dish.id] ?: 0) + 1 },
                                    onRemove = { val n=(cart[dish.id] ?: 0)-1; if(n<=0) cart.remove(dish.id) else cart[dish.id]=n })
                            }
                        }
                    }
                }
                else -> {
                    if (cart.isEmpty()) {
                        Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("🛍", fontSize = 48.sp)
                            Spacer(Modifier.height(12.dp))
                            Text("Корзина пока пуста", color = White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                            Text("Добавь что-нибудь вкусное из меню", color = Muted)
                            Spacer(Modifier.height(16.dp))
                            Button(onClick = { page = "Меню" }, colors = ButtonDefaults.buttonColors(containerColor = Gold)) { Text("Перейти в меню", color = Color.Black) }
                        }
                    } else {
                        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(allDishes.filter { cart.containsKey(it.id) }) { dish ->
                                DishCard(dish, null, cart[dish.id] ?: 0,
                                    onAdd = { cart[dish.id] = (cart[dish.id] ?: 0) + 1 },
                                    onRemove = { val n=(cart[dish.id] ?: 0)-1; if(n<=0) cart.remove(dish.id) else cart[dish.id]=n })
                            }
                        }
                        Column(Modifier.fillMaxWidth().background(Panel).padding(18.dp)) {
                            Text("Итого: ${cartTotal.toInt()} сом", color = Gold, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                            Spacer(Modifier.height(8.dp))
                            Button(onClick = { /* checkout needs restaurant ordering backend */ },
                                modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Gold)) {
                                Text("Заказ собран", color = Color.Black, fontWeight = FontWeight.Bold)
                            }
                            Text("Для отправки заказа нужен подключённый сервис кафе.", color = Muted, fontSize = 11.sp)
                        }
                    }
                }
            }
            Row(Modifier.fillMaxWidth().background(Panel).padding(horizontal = 8.dp, vertical = 8.dp), horizontalArrangement = Arrangement.SpaceAround) {
                listOf("Главная", "Меню", "Корзина").forEach { label ->
                    val selected = page == label
                    Column(Modifier.weight(1f).clickable { page = label }.padding(vertical = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(when(label) { "Главная" -> "⌂"; "Меню" -> "☷"; else -> "🛍" }, color = if(selected) Gold else Muted, fontSize = 20.sp)
                        Text(label, color = if(selected) Gold else Muted, fontSize = 12.sp, fontWeight = if(selected) FontWeight.Bold else FontWeight.Normal)
                    }
                }
            }
        }
    }
}

@Composable
fun DishCard(dish: Dish, rating: String?, count: Int, onAdd: () -> Unit, onRemove: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(58.dp).background(Color(0xFF293747), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
            Text(emojiFor(dish.category), fontSize = 27.sp)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(dish.name, color = White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            Text(dish.category, color = Muted, fontSize = 11.sp)
            if (rating != null) Text("⭐ $rating · Выбор гостей", color = Gold, fontSize = 11.sp)
            Spacer(Modifier.height(4.dp))
            Text("${dish.price.toDouble().toInt()} сом${if(dish.unit.isNotBlank()) " / ${dish.unit}" else ""}", color = Gold, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        }
        if (count == 0) {
            Button(onClick = onAdd, contentPadding = PaddingValues(horizontal = 13.dp, vertical = 8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Gold), shape = RoundedCornerShape(10.dp)) {
                Text("+", color = Color.Black, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
        } else {
            Row(verticalAlignment = Alignment.CenterVertically) {
                SmallAction("−", onRemove)
                Text("$count", color = White, modifier = Modifier.padding(horizontal = 9.dp), fontWeight = FontWeight.Bold)
                SmallAction("+", onAdd)
            }
        }
    }
}

@Composable
private fun SmallAction(label: String, onClick: () -> Unit) {
    Box(Modifier.size(30.dp).background(Gold, RoundedCornerShape(9.dp)).clickable { onClick() }, contentAlignment = Alignment.Center) {
        Text(label, color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 18.sp)
    }
}

private fun emojiFor(category: String): String = when {
    category.contains("Салат", true) -> "🥗"
    category.contains("закуск", true) || category.contains("нарез", true) -> "🧀"
    category.contains("суп", true) -> "🍜"
    category.contains("пиц", true) -> "🍕"
    category.contains("мяс", true) || category.contains("мангал", true) || category.contains("шаш", true) -> "🍢"
    category.contains("напит", true) || category.contains("чай", true) -> "🥤"
    category.contains("десерт", true) || category.contains("торт", true) -> "🍰"
    else -> "🍽️"
}
